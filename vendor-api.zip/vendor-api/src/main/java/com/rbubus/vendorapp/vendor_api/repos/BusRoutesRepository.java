package com.rbubus.vendorapp.vendor_api.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rbubus.vendorapp.vendor_api.domain.BusRoute;


public interface BusRoutesRepository extends JpaRepository<BusRoute, Long> {
}
