package com.rbubus.vendorapp.vendor_api.service;

import com.rbubus.vendorapp.vendor_api.domain.BUSVENDOR;
import com.rbubus.vendorapp.vendor_api.model.BUSVENDORDTO;
import com.rbubus.vendorapp.vendor_api.repos.BUSVENDORRepository;
import com.rbubus.vendorapp.vendor_api.util.WebUtils;
import java.util.List;
import java.util.stream.Collectors;
import javax.transaction.Transactional;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;


@Service
public class BUSVENDORService {
	
    private final BUSVENDORRepository bUSVENDORRepository;
    //DI
    public BUSVENDORService(final BUSVENDORRepository bUSVENDORRepository) {
        this.bUSVENDORRepository = bUSVENDORRepository;
    }

    public List<BUSVENDORDTO> findAll() {
        return bUSVENDORRepository.findAll(Sort.by("vendorid"))
                .stream()
                .map(bUSVENDOR -> mapToDTO(bUSVENDOR, new BUSVENDORDTO()))
                .collect(Collectors.toList());
    }

    public BUSVENDORDTO get(final Long vendorid) {
        return bUSVENDORRepository.findById(vendorid)
                .map(bUSVENDOR -> mapToDTO(bUSVENDOR, new BUSVENDORDTO()))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    public Long create(final BUSVENDORDTO bUSVENDORDTO) {
        final BUSVENDOR bUSVENDOR = new BUSVENDOR();
        mapToEntity(bUSVENDORDTO, bUSVENDOR);
        return bUSVENDORRepository.save(bUSVENDOR).getVendorid();
    }

    public void update(final Long vendorid, final BUSVENDORDTO bUSVENDORDTO) {
        final BUSVENDOR bUSVENDOR = bUSVENDORRepository.findById(vendorid)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        mapToEntity(bUSVENDORDTO, bUSVENDOR);
        bUSVENDORRepository.save(bUSVENDOR);
    }

    public void delete(final Long vendorid) {
        bUSVENDORRepository.deleteById(vendorid);
    }

    private BUSVENDORDTO mapToDTO(final BUSVENDOR bUSVENDOR, final BUSVENDORDTO bUSVENDORDTO) {
        bUSVENDORDTO.setVendorid(bUSVENDOR.getVendorid());
        bUSVENDORDTO.setVendorname(bUSVENDOR.getVendorname());
        bUSVENDORDTO.setDescription(bUSVENDOR.getDescription());
        bUSVENDORDTO.setState(bUSVENDOR.getState());
        bUSVENDORDTO.setCiti(bUSVENDOR.getCiti());
        bUSVENDORDTO.setPan(bUSVENDOR.getPan());
        bUSVENDORDTO.setGst(bUSVENDOR.getGst());
        bUSVENDORDTO.setBusinessname(bUSVENDOR.getBusinessname());
        return bUSVENDORDTO;
    }

    private BUSVENDOR mapToEntity(final BUSVENDORDTO bUSVENDORDTO, final BUSVENDOR bUSVENDOR) {
        bUSVENDOR.setVendorname(bUSVENDORDTO.getVendorname());
        bUSVENDOR.setDescription(bUSVENDORDTO.getDescription());
        bUSVENDOR.setState(bUSVENDORDTO.getState());
        bUSVENDOR.setCiti(bUSVENDORDTO.getCiti());
        bUSVENDOR.setPan(bUSVENDORDTO.getPan());
        bUSVENDOR.setGst(bUSVENDORDTO.getGst());
        bUSVENDOR.setBusinessname(bUSVENDORDTO.getBusinessname());
        return bUSVENDOR;
    }

    @Transactional
    public String getReferencedWarning(final Long vendorid) {
        final BUSVENDOR bUSVENDOR = bUSVENDORRepository.findById(vendorid)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        if (!bUSVENDOR.getVendoridfkBUSESs().isEmpty()) {
            return WebUtils.getMessage("bUSVENDOR.bUSES.oneToMany.referenced", bUSVENDOR.getVendoridfkBUSESs().iterator().next().getBusid());
        }
        return null;
    }

}
