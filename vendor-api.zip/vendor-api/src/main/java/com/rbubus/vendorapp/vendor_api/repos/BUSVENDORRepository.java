package com.rbubus.vendorapp.vendor_api.repos;

import com.rbubus.vendorapp.vendor_api.domain.BUSVENDOR;
import org.springframework.data.jpa.repository.JpaRepository;


public interface BUSVENDORRepository extends JpaRepository<BUSVENDOR, Long> {
}
