package com.rbubus.vendorapp.vendor_api.repos;

import com.rbubus.vendorapp.vendor_api.domain.BUSES;
import org.springframework.data.jpa.repository.JpaRepository;


public interface BUSESRepository extends JpaRepository<BUSES, Long> {
}
