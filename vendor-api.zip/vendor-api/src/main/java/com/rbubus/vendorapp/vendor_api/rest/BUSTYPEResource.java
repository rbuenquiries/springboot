package com.rbubus.vendorapp.vendor_api.rest;

import com.rbubus.vendorapp.vendor_api.model.BUSTYPEDTO;
import com.rbubus.vendorapp.vendor_api.service.BUSTYPEService;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.util.List;
import javax.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/bUSTYPEs", produces = MediaType.APPLICATION_JSON_VALUE)
public class BUSTYPEResource {

    private final BUSTYPEService bUSTYPEService;

    public BUSTYPEResource(final BUSTYPEService bUSTYPEService) {
        this.bUSTYPEService = bUSTYPEService;
    }

    @GetMapping
    public ResponseEntity<List<BUSTYPEDTO>> getAllBUSTYPEs() {
        return ResponseEntity.ok(bUSTYPEService.findAll());
    }

    @GetMapping("/{bustypeid}")
    public ResponseEntity<BUSTYPEDTO> getBUSTYPE(@PathVariable final Long bustypeid) {
        return ResponseEntity.ok(bUSTYPEService.get(bustypeid));
    }

    @PostMapping
    @ApiResponse(responseCode = "201")
    public ResponseEntity<Long> createBUSTYPE(@RequestBody @Valid final BUSTYPEDTO bUSTYPEDTO) {
        return new ResponseEntity<>(bUSTYPEService.create(bUSTYPEDTO), HttpStatus.CREATED);
    }

    @PutMapping("/{bustypeid}")
    public ResponseEntity<Void> updateBUSTYPE(@PathVariable final Long bustypeid,
            @RequestBody @Valid final BUSTYPEDTO bUSTYPEDTO) {
        bUSTYPEService.update(bustypeid, bUSTYPEDTO);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{bustypeid}")
    @ApiResponse(responseCode = "204")
    public ResponseEntity<Void> deleteBUSTYPE(@PathVariable final Long bustypeid) {
        bUSTYPEService.delete(bustypeid);
        return ResponseEntity.noContent().build();
    }

}
