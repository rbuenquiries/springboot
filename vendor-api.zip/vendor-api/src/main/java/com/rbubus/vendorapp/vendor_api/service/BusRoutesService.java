package com.rbubus.vendorapp.vendor_api.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.rbubus.vendorapp.vendor_api.domain.BusRoute;
import com.rbubus.vendorapp.vendor_api.model.BusRouteDTO;
import com.rbubus.vendorapp.vendor_api.repos.BusRoutesRepository;

@Service
public class BusRoutesService {
	
	 private final	BusRoutesRepository busRoutesRepository;
	

	    public BusRoutesService(final BusRoutesRepository busRoutesRepository) {
	        this.busRoutesRepository = busRoutesRepository;
	    }



		public List<BusRouteDTO> findAll() {
			return busRoutesRepository.findAll(Sort.by("busrouteid")).stream().map(busroutes -> mapToDTO(busroutes, new BusRouteDTO()))
					.collect(Collectors.toList());
		}

		public BusRouteDTO get(final Long busrouteid) {
			return busRoutesRepository.findById(busrouteid).map(busroutes -> mapToDTO(busroutes, new BusRouteDTO()))
					.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
		}

		public Long create(final BusRouteDTO busRouteDTO) {
			final BusRoute busRoute= new BusRoute();
			mapToEntity(busRouteDTO, busRoute);
			return busRoutesRepository.save(busRoute).getBusrouteid();
		}

		public void update(final Long busrouteId, final BusRouteDTO busRouteDTO) {
			final BusRoute busRoute= busRoutesRepository.findById(busrouteId)
					.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
			mapToEntity(busRouteDTO, busRoute);
			busRoutesRepository.save(busRoute);
		}

		public void delete(final Long busrouteId) {
			busRoutesRepository.deleteById(busrouteId);
		}

		private BusRouteDTO mapToDTO(final BusRoute busRoute, final BusRouteDTO busRouteDTO) {
			busRouteDTO.setBusid(busRoute.getBusid());
			busRouteDTO.setBusrouteid(busRoute.getBusrouteid());
			busRouteDTO.setSourceciti(busRoute.getSourceciti());
			busRouteDTO.setDestciti(busRoute.getDestciti());
			busRouteDTO.setRundate(busRoute.getRundate());
			return busRouteDTO;
		}

		private BusRoute mapToEntity(final BusRouteDTO busRouteDTO, final BusRoute busRoute) {
			busRoute.setBusid(busRouteDTO.getBusid());
			busRoute.setBusrouteid(busRouteDTO.getBusrouteid());
			busRoute.setSourceciti(busRouteDTO.getSourceciti());
			busRoute.setDestciti(busRouteDTO.getDestciti());
			busRoute.setRundate(busRouteDTO.getRundate());
			return busRoute;
		}
}
