package com.rbubus.vendorapp.vendor_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class VendorApiApplication {

    public static void main(final String[] args) {
        SpringApplication.run(VendorApiApplication.class, args);
    }

}
