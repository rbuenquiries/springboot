package com.rbubus.vendorapp.vendor_api.repos;

import com.rbubus.vendorapp.vendor_api.domain.BUSTYPE;
import org.springframework.data.jpa.repository.JpaRepository;


public interface BUSTYPERepository extends JpaRepository<BUSTYPE, Long> {
}
