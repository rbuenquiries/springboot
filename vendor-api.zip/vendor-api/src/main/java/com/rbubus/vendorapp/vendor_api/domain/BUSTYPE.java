package com.rbubus.vendorapp.vendor_api.domain;

import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class BUSTYPE {

    @Id
    @Column(nullable = false, updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bustypeid;

    @Column(nullable = false)
    private String bustype;

    @Column(nullable = false, name = "\"description\"")
    private String description;

    @Column
    private String isactive;

    @OneToMany(mappedBy = "bustypeid")
    private Set<BUSES> bustypeidBUSESs;

    public Long getBustypeid() {
        return bustypeid;
    }

    public void setBustypeid(final Long bustypeid) {
        this.bustypeid = bustypeid;
    }

    public String getBustype() {
        return bustype;
    }

    public void setBustype(final String bustype) {
        this.bustype = bustype;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public String getIsactive() {
        return isactive;
    }

    public void setIsactive(final String isactive) {
        this.isactive = isactive;
    }

    public Set<BUSES> getBustypeidBUSESs() {
        return bustypeidBUSESs;
    }

    public void setBustypeidBUSESs(final Set<BUSES> bustypeidBUSESs) {
        this.bustypeidBUSESs = bustypeidBUSESs;
    }

}
