package com.rbubus.vendorapp.vendor_api.service;

import com.rbubus.vendorapp.vendor_api.domain.BUSTYPE;
import com.rbubus.vendorapp.vendor_api.model.BUSTYPEDTO;
import com.rbubus.vendorapp.vendor_api.repos.BUSTYPERepository;
import com.rbubus.vendorapp.vendor_api.util.WebUtils;
import java.util.List;
import java.util.stream.Collectors;
import javax.transaction.Transactional;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;


@Service
public class BUSTYPEService {

    private final BUSTYPERepository bUSTYPERepository;

    public BUSTYPEService(final BUSTYPERepository bUSTYPERepository) {
        this.bUSTYPERepository = bUSTYPERepository;
    }

    public List<BUSTYPEDTO> findAll() {
        return bUSTYPERepository.findAll(Sort.by("bustypeid"))
                .stream()
                .map(bUSTYPE -> mapToDTO(bUSTYPE, new BUSTYPEDTO()))
                .collect(Collectors.toList());
    }

    public BUSTYPEDTO get(final Long bustypeid) {
        return bUSTYPERepository.findById(bustypeid)
                .map(bUSTYPE -> mapToDTO(bUSTYPE, new BUSTYPEDTO()))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    public Long create(final BUSTYPEDTO bUSTYPEDTO) {
        final BUSTYPE bUSTYPE = new BUSTYPE();
        mapToEntity(bUSTYPEDTO, bUSTYPE);
        return bUSTYPERepository.save(bUSTYPE).getBustypeid();
    }

    public void update(final Long bustypeid, final BUSTYPEDTO bUSTYPEDTO) {
        final BUSTYPE bUSTYPE = bUSTYPERepository.findById(bustypeid)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        mapToEntity(bUSTYPEDTO, bUSTYPE);
        bUSTYPERepository.save(bUSTYPE);
    }

    public void delete(final Long bustypeid) {
        bUSTYPERepository.deleteById(bustypeid);
    }

    private BUSTYPEDTO mapToDTO(final BUSTYPE bUSTYPE, final BUSTYPEDTO bUSTYPEDTO) {
        bUSTYPEDTO.setBustypeid(bUSTYPE.getBustypeid());
        bUSTYPEDTO.setBustype(bUSTYPE.getBustype());
        bUSTYPEDTO.setDescription(bUSTYPE.getDescription());
        bUSTYPEDTO.setIsactive(bUSTYPE.getIsactive());
        return bUSTYPEDTO;
    }

    private BUSTYPE mapToEntity(final BUSTYPEDTO bUSTYPEDTO, final BUSTYPE bUSTYPE) {
        bUSTYPE.setBustype(bUSTYPEDTO.getBustype());
        bUSTYPE.setDescription(bUSTYPEDTO.getDescription());
        bUSTYPE.setIsactive(bUSTYPEDTO.getIsactive());
        return bUSTYPE;
    }

    @Transactional
    public String getReferencedWarning(final Long bustypeid) {
        final BUSTYPE bUSTYPE = bUSTYPERepository.findById(bustypeid)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        if (!bUSTYPE.getBustypeidBUSESs().isEmpty()) {
            return WebUtils.getMessage("bUSTYPE.bUSES.oneToMany.referenced", bUSTYPE.getBustypeidBUSESs().iterator().next().getBusid());
        }
        return null;
    }

}
