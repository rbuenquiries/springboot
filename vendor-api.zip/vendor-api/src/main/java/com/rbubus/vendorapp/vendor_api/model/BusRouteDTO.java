package com.rbubus.vendorapp.vendor_api.model;

import javax.validation.constraints.NotNull;

public class BusRouteDTO {

	
	private Long busrouteid;

	@NotNull
	private String sourceciti;

	@NotNull
	private String destciti;

	@NotNull
	private Long busid;

	@NotNull
	private String rundate;

	public Long getBusrouteid() {
		return busrouteid;
	}

	public void setBusrouteid(Long busrouteid) {
		this.busrouteid = busrouteid;
	}

	public String getSourceciti() {
		return sourceciti;
	}

	public void setSourceciti(String sourceciti) {
		this.sourceciti = sourceciti;
	}

	public String getDestciti() {
		return destciti;
	}

	public void setDestciti(String destciti) {
		this.destciti = destciti;
	}

	public Long getBusid() {
		return busid;
	}

	public void setBusid(Long busid) {
		this.busid = busid;
	}

	public void setRundate(String rundate) {
		this.rundate = rundate;
	}

	public String getRundate() {
		return rundate;
	}

}
