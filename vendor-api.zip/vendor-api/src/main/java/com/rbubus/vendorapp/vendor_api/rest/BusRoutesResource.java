package com.rbubus.vendorapp.vendor_api.rest;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rbubus.vendorapp.vendor_api.model.BusRouteDTO;
import com.rbubus.vendorapp.vendor_api.service.BusRoutesService;

import io.swagger.v3.oas.annotations.responses.ApiResponse;


@RestController
@CrossOrigin(origins = "http://localhost:8095")
@RequestMapping(value = "/api/busroutes", produces = MediaType.APPLICATION_JSON_VALUE)
public class BusRoutesResource {

    private final BusRoutesService busRoutesService;

    public BusRoutesResource(final BusRoutesService busRoutesService) {
        this.busRoutesService = busRoutesService;
    }

    @GetMapping
    public ResponseEntity<List<BusRouteDTO>> getAllBusRoutes() {
        return ResponseEntity.ok(busRoutesService.findAll());
    }

    @GetMapping("/{busrouteId}")
    public ResponseEntity<BusRouteDTO> getBUSES(@PathVariable final Long busrouteId) {
        return ResponseEntity.ok(busRoutesService.get(busrouteId));
    }

    @PostMapping
    @ApiResponse(responseCode = "201")
    public ResponseEntity<Long> createBUSES(@RequestBody @Valid final BusRouteDTO busRouteDTO) {
        return new ResponseEntity<>(busRoutesService.create(busRouteDTO), HttpStatus.CREATED);
    }

    @PutMapping("/{busrouteId}")
    public ResponseEntity<Void> updateBUSES(@PathVariable final Long busrouteId,
            @RequestBody @Valid final BusRouteDTO busRouteDTO) {
    	busRoutesService.update(busrouteId, busRouteDTO);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{busrouteId}")
    @ApiResponse(responseCode = "204")
    public ResponseEntity<Void> deleteBUSES(@PathVariable final Long busrouteId) {
    	busRoutesService.delete(busrouteId);
        return ResponseEntity.noContent().build();
    }

}
