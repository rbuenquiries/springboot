package com.rbubus.vendorapp.vendor_api.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BusRoute")
public class BusRoute {

	@Id
	@Column(nullable = false, updatable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long busrouteid;

	@Column(nullable = false)
	private String sourceciti;

	@Column(nullable = false, name = "\"destciti\"")
	private String destciti;

	@Column(nullable = false)
	private Long busid;

	@Column(nullable = false)
	private String rundate;

	public Long getBusrouteid() {
		return busrouteid;
	}

	public void setBusrouteid(Long busrouteid) {
		this.busrouteid = busrouteid;
	}

	public String getSourceciti() {
		return sourceciti;
	}

	public void setSourceciti(String sourceciti) {
		this.sourceciti = sourceciti;
	}

	public String getDestciti() {
		return destciti;
	}

	public void setDestciti(String destciti) {
		this.destciti = destciti;
	}

	public Long getBusid() {
		return busid;
	}

	public void setBusid(Long busid) {
		this.busid = busid;
	}

	public void setRundate(String rundate) {
		this.rundate = rundate;
	}

	public String getRundate() {
		return rundate;
	}

}
